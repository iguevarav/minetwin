# Diagnóstico y remediación de desbalance

## Diagnóstico sin reentrenamiento

| field | value | source_file |
| --- | --- | --- |
| decision_rule | minimum_expected_cost | results\final_diagnostics_verified\diagnostics.json |
| loss_weighting | sqrt_inverse_frequency | results\final_diagnostics_verified\diagnostics.json |
| class_weights | [0.5201372581819331, 1.6893881312666181, 1.7213029137633598, 1.8200649728677871, 1.7846848461283016] | results\final_diagnostics_verified\diagnostics.json |
| double_correction | True | results\final_diagnostics_verified\diagnostics.json |

La regla histórica es mínimo costo esperado. La pérdida usa pesos de raíz del inverso de frecuencia; junto con la matriz de costos en la decisión, existe doble corrección del desbalance.

Las matrices y distribuciones predichas están en `pre_confusion.csv` y `pre_predicted_distribution.csv`.

| regime | kind | class | examples | source_file |
| --- | --- | --- | --- | --- |
| local | actual | 0 | 4910 | results/final_diagnostics_verified/diagnostics.json |
| local | actual | 1 | 16 | results/final_diagnostics_verified/diagnostics.json |
| local | actual | 2 | 14 | results/final_diagnostics_verified/diagnostics.json |
| local | actual | 3 | 30 | results/final_diagnostics_verified/diagnostics.json |
| local | actual | 4 | 76 | results/final_diagnostics_verified/diagnostics.json |
| local | predicted_cost_rule | 0 | 141 | results/final_diagnostics_verified/diagnostics.json |
| local | predicted_cost_rule | 1 | 7 | results/final_diagnostics_verified/diagnostics.json |
| local | predicted_cost_rule | 2 | 4 | results/final_diagnostics_verified/diagnostics.json |
| local | predicted_cost_rule | 3 | 13 | results/final_diagnostics_verified/diagnostics.json |
| local | predicted_cost_rule | 4 | 4881 | results/final_diagnostics_verified/diagnostics.json |
| centralized | actual | 0 | 4910 | results/final_diagnostics_verified/diagnostics.json |
| centralized | actual | 1 | 16 | results/final_diagnostics_verified/diagnostics.json |
| centralized | actual | 2 | 14 | results/final_diagnostics_verified/diagnostics.json |
| centralized | actual | 3 | 30 | results/final_diagnostics_verified/diagnostics.json |
| centralized | actual | 4 | 76 | results/final_diagnostics_verified/diagnostics.json |
| centralized | predicted_cost_rule | 0 | 30 | results/final_diagnostics_verified/diagnostics.json |
| centralized | predicted_cost_rule | 1 | 1 | results/final_diagnostics_verified/diagnostics.json |
| centralized | predicted_cost_rule | 2 | 5 | results/final_diagnostics_verified/diagnostics.json |
| centralized | predicted_cost_rule | 3 | 8 | results/final_diagnostics_verified/diagnostics.json |
| centralized | predicted_cost_rule | 4 | 5002 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | actual | 0 | 4910 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | actual | 1 | 16 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | actual | 2 | 14 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | actual | 3 | 30 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | actual | 4 | 76 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | predicted_cost_rule | 0 | 61 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | predicted_cost_rule | 1 | 2 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | predicted_cost_rule | 2 | 9 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | predicted_cost_rule | 3 | 9 | results/final_diagnostics_verified/diagnostics.json |
| fedavg | predicted_cost_rule | 4 | 4965 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | actual | 0 | 4910 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | actual | 1 | 16 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | actual | 2 | 14 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | actual | 3 | 30 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | actual | 4 | 76 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | predicted_cost_rule | 0 | 66 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | predicted_cost_rule | 1 | 1 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | predicted_cost_rule | 2 | 11 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | predicted_cost_rule | 3 | 3 | results/final_diagnostics_verified/diagnostics.json |
| fedprox | predicted_cost_rule | 4 | 4965 | results/final_diagnostics_verified/diagnostics.json |

| split | class | examples | share | source_file |
| --- | --- | --- | --- | --- |
| train | 0 | 23546 | 0.7392546544849455 | results\phase2_cache\train.npz |
| train | 1 | 2232 | 0.0700762927380616 | results\phase2_cache\train.npz |
| train | 2 | 2150 | 0.0675018052808389 | results\phase2_cache\train.npz |
| train | 3 | 1923 | 0.060374870490722425 | results\phase2_cache\train.npz |
| train | 4 | 2000 | 0.06279237700543154 | results\phase2_cache\train.npz |
| validation | 0 | 4910 | 0.9730479587792311 | results\phase2_cache\validation.npz |
| validation | 1 | 16 | 0.0031708283789139914 | results\phase2_cache\validation.npz |
| validation | 2 | 14 | 0.0027744748315497426 | results\phase2_cache\validation.npz |
| validation | 3 | 30 | 0.005945303210463734 | results\phase2_cache\validation.npz |
| validation | 4 | 76 | 0.015061434799841459 | results\phase2_cache\validation.npz |

## Selección interna agrupada

| variant | mean_cost_mean | mean_cost_sd | macro_pr_auc_mean | macro_pr_auc_sd | balanced_accuracy_mean | balanced_accuracy_sd | accuracy_mean | accuracy_sd | folds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| a_weighted_cost | 8.455426765151891 | 0.16542046019256182 | 0.256527225444693 | 0.005333754903834454 | 0.22224434256806863 | 0.0027574348252226467 | 0.19078996950878152 | 0.016090996608550193 | 5 |
| b_unweighted_cost | 8.346975427278657 | 0.32630687343042775 | 0.26220703955957136 | 0.004432642663680357 | 0.24701606952939148 | 0.010405653595402154 | 0.31003777849798503 | 0.036618763450587025 | 5 |
| c_weighted_argmax | 37.27319345771106 | 2.334243275716476 | 0.256527225444693 | 0.005333754903834454 | 0.2612776496391268 | 0.044934231778309436 | 0.8543611861489463 | 0.01834464728721431 | 5 |
| d_unweighted_cost_prior | 8.866671639310336 | 0.5753059285105857 | 0.2698156658602634 | 0.0028225291369988544 | 0.2713704970197812 | 0.008318064628192786 | 0.4619818862070761 | 0.05462746669559898 | 5 |

Cada fold retiene vehículos completos y evalúa solamente su última ventana. `validation` no se usó para seleccionar la variante.

La corrección de la variante d ajusta el prior de entrenamiento a la frecuencia de clase de la última ventana almacenada por vehículo dentro del fold de entrenamiento.

## Modelos de referencia

| model | mean_cost_mean | mean_cost_sd | macro_pr_auc_mean | macro_pr_auc_sd | balanced_accuracy_mean | balanced_accuracy_sd | accuracy_mean | accuracy_sd | folds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gradient_boosted_stumps | 9.122972715981142 | 0.0005463316892729194 | 0.23110774535377904 | 0.00462765156435003 | 0.2 | 0.0 | 0.08492574057529442 | 7.327318840807706e-05 | 5 |
| logistic_regression | 8.71667794873547 | 0.10921584715706482 | 0.25910307708353936 | 0.0040840263903488515 | 0.21567373118524685 | 0.0016771411290052397 | 0.16190971606764892 | 0.009254600581541301 | 5 |

## Evaluación multisemilla de la variante elegida

| regime | metric | mean | sd | n | source_file |
| --- | --- | --- | --- | --- | --- |
| centralized | mean_cost | 9.568866428854538 | 0.10236512989438963 | 10 | results/remediation_multiseed/metrics.csv |
| centralized | macro_pr_auc | 0.20947921046593593 | 0.0041290463415671955 | 10 | results/remediation_multiseed/metrics.csv |
| centralized | balanced_accuracy | 0.21025929896023152 | 0.005837821016358545 | 10 | results/remediation_multiseed/metrics.csv |
| centralized | accuracy | 0.05081252477209671 | 0.009436119092437084 | 10 | results/remediation_multiseed/metrics.csv |
| fedavg | mean_cost | 9.487019421323819 | 0.07831659534459647 | 10 | results/remediation_multiseed/metrics.csv |
| fedavg | macro_pr_auc | 0.21273765415161466 | 0.0019018170056272054 | 10 | results/remediation_multiseed/metrics.csv |
| fedavg | balanced_accuracy | 0.20812072569407225 | 0.003657078970623548 | 10 | results/remediation_multiseed/metrics.csv |
| fedavg | accuracy | 0.057332540626238604 | 0.006634269871624065 | 10 | results/remediation_multiseed/metrics.csv |
| fedprox | mean_cost | 9.420630202140309 | 0.08726352680191128 | 10 | results/remediation_multiseed/metrics.csv |
| fedprox | macro_pr_auc | 0.21253763674771128 | 0.0018840368837451612 | 10 | results/remediation_multiseed/metrics.csv |
| fedprox | balanced_accuracy | 0.2078288133776396 | 0.002037572957424072 | 10 | results/remediation_multiseed/metrics.csv |
| fedprox | accuracy | 0.05945303210463733 | 0.006970390475302111 | 10 | results/remediation_multiseed/metrics.csv |
| local | mean_cost | 9.153091557669441 | 0.13280982907815284 | 10 | results/remediation_multiseed/metrics.csv |
| local | macro_pr_auc | 0.21360113575944933 | 0.005944438871390264 | 10 | results/remediation_multiseed/metrics.csv |
| local | balanced_accuracy | 0.2144990084682174 | 0.0036115466993977144 | 10 | results/remediation_multiseed/metrics.csv |
| local | accuracy | 0.11987713040031708 | 0.04178689887498627 | 10 | results/remediation_multiseed/metrics.csv |

## Estadística primaria: costo medio

| reference | candidate | metric | mean_difference | ci_95_lower | ci_95_upper | wilcoxon_statistic | p_value | rank_biserial | nonzero_pairs | test_method | p_value_holm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| local | fedavg | mean_cost | 0.3339278636543792 | 0.26074118113357037 | 0.395461751882679 | 0.0 | 0.001953125 | 1.0 | 10 | exact | 0.009765625 |
| local | fedprox | mean_cost | 0.2675386444708675 | 0.20005895759016978 | 0.3275673801030512 | 0.0 | 0.001953125 | 1.0 | 10 | exact | 0.009765625 |
| centralized | fedavg | mean_cost | -0.08184700753071752 | -0.12045233848593014 | -0.0452011494252869 | 1.0 | 0.00390625 | -0.9636363636363636 | 10 | exact | 0.009765625 |
| centralized | fedprox | mean_cost | -0.14823622671422926 | -0.18351169242964732 | -0.11293896155370625 | 0.0 | 0.001953125 | -1.0 | 10 | exact | 0.009765625 |
| fedavg | fedprox | mean_cost | -0.06638921918351173 | -0.08810939357907249 | -0.045698573127229455 | 0.0 | 0.001953125 | -1.0 | 10 | exact | 0.009765625 |

Holm se aplica únicamente a los cinco contrastes de costo medio. Las métricas secundarias se reportan sin ajuste en `secondary_statistics.csv`.

## Estadísticas secundarias

| reference | candidate | metric | mean_difference | ci_95_lower | ci_95_upper | wilcoxon_statistic | p_value | rank_biserial | nonzero_pairs | test_method |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| local | fedavg | macro_pr_auc | -0.0008634816078346514 | -0.00505545347945367 | 0.0031983368311557527 | 24.0 | 0.76953125 | -0.12727272727272726 | 10 | exact |
| local | fedavg | balanced_accuracy | -0.0063782827741451446 | -0.009256243970414826 | -0.002771730624933016 | 4.0 | 0.013671875 | -0.8545454545454545 | 10 | exact |
| local | fedavg | accuracy | -0.06254458977407848 | -0.08824861276258421 | -0.04389466904478797 | 0.0 | 0.001953125 | -1.0 | 10 | exact |
| local | fedprox | macro_pr_auc | -0.0010634990117380171 | -0.00549063047155473 | 0.003267813483303378 | 23.0 | 0.6953125 | -0.16363636363636364 | 10 | exact |
| local | fedprox | balanced_accuracy | -0.0066701950905777765 | -0.008780249758816605 | -0.004829575115232091 | 0.0 | 0.001953125 | -1.0 | 10 | exact |
| local | fedprox | accuracy | -0.060424098295679754 | -0.08529577883472059 | -0.041834621482362264 | 0.0 | 0.001953125 | -1.0 | 10 | exact |
| centralized | fedavg | macro_pr_auc | 0.003258443685678733 | 0.0002141547201239424 | 0.006082655910040133 | 9.0 | 0.064453125 | 0.6727272727272727 | 10 | exact |
| centralized | fedavg | balanced_accuracy | -0.00213857326615928 | -0.0055977596741344 | 0.0009067826133561966 | 27.0 | 1.0 | 0.01818181818181818 | 10 | exact |
| centralized | fedavg | accuracy | 0.006520015854141895 | 0.00307173999207293 | 0.010146650812524773 | 3.0 | 0.009765625 | 0.8909090909090909 | 10 | exact |
| centralized | fedprox | macro_pr_auc | 0.0030584262817753673 | -0.00017162229232864368 | 0.006093315833175473 | 11.0 | 0.10546875 | 0.6 | 10 | exact |
| centralized | fedprox | balanced_accuracy | -0.0024304855825919127 | -0.005551666845321046 | 0.0006302658377103645 | 21.0 | 0.556640625 | -0.23636363636363636 | 10 | exact |
| centralized | fedprox | accuracy | 0.008640507332540629 | 0.005192231470471662 | 0.01232659532302814 | 1.0 | 0.00390625 | 0.9636363636363636 | 10 | exact |
| fedavg | fedprox | macro_pr_auc | -0.00020001740390336586 | -0.0009269886724743839 | 0.0004043534015766345 | 25.0 | 0.845703125 | 0.09090909090909091 | 10 | exact |
| fedavg | fedprox | balanced_accuracy | -0.0002919123164326326 | -0.0026469671186622303 | 0.0012579456533390481 | 11.0 | 0.203125 | 0.5111111111111111 | 9 | exact |
| fedavg | fedprox | accuracy | 0.0021204914783987325 | 0.0009314308363059839 | 0.0032699167657550534 | 4.0 | 0.03281585897343788 | 0.8222222222222222 | 9 | normal |

La procedencia, commit, hardware y tiempos están en `results/remediation_multiseed/manifest.json`. Las figuras PNG a 300 dpi están adjuntas en este directorio.
