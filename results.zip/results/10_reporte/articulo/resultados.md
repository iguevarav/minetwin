# Resultados reproducibles de MineTwin

## Eda Particiones

| partition | vehicles | readouts | variables | missing_values | source_file |
| --- | --- | --- | --- | --- | --- |
| train | 23550 | 1122452 | 105 | 354634 | results/01_datos/summary.json |
| validation | 5046 | 196227 | 105 | 60339 | results/01_datos/summary.json |
| test | 5045 | 198140 | 105 | 66403 | results/01_datos/summary.json |

## Eda Clases

| partition | scope | node | class | examples | source_file |
| --- | --- | --- | --- | --- | --- |
| train | global |  | 0 | 23546 | results/04_seleccion_modelo/eda.json |
| train | global |  | 1 | 2232 | results/04_seleccion_modelo/eda.json |
| train | global |  | 2 | 2150 | results/04_seleccion_modelo/eda.json |
| train | global |  | 3 | 1923 | results/04_seleccion_modelo/eda.json |
| train | global |  | 4 | 2000 | results/04_seleccion_modelo/eda.json |
| train | node | alpha | 0 | 6734 | results/04_seleccion_modelo/eda.json |
| train | node | alpha | 1 | 597 | results/04_seleccion_modelo/eda.json |
| train | node | alpha | 2 | 572 | results/04_seleccion_modelo/eda.json |
| train | node | alpha | 3 | 516 | results/04_seleccion_modelo/eda.json |
| train | node | alpha | 4 | 535 | results/04_seleccion_modelo/eda.json |
| train | node | beta | 0 | 9561 | results/04_seleccion_modelo/eda.json |
| train | node | beta | 1 | 910 | results/04_seleccion_modelo/eda.json |
| train | node | beta | 2 | 880 | results/04_seleccion_modelo/eda.json |
| train | node | beta | 3 | 772 | results/04_seleccion_modelo/eda.json |
| train | node | beta | 4 | 800 | results/04_seleccion_modelo/eda.json |
| train | node | gamma | 0 | 7251 | results/04_seleccion_modelo/eda.json |
| train | node | gamma | 1 | 725 | results/04_seleccion_modelo/eda.json |
| train | node | gamma | 2 | 698 | results/04_seleccion_modelo/eda.json |
| train | node | gamma | 3 | 635 | results/04_seleccion_modelo/eda.json |
| train | node | gamma | 4 | 665 | results/04_seleccion_modelo/eda.json |
| validation | global |  | 0 | 4910 | results/04_seleccion_modelo/eda.json |
| validation | global |  | 1 | 16 | results/04_seleccion_modelo/eda.json |
| validation | global |  | 2 | 14 | results/04_seleccion_modelo/eda.json |
| validation | global |  | 3 | 30 | results/04_seleccion_modelo/eda.json |
| validation | global |  | 4 | 76 | results/04_seleccion_modelo/eda.json |
| validation | node | alpha | 0 | 1437 | results/04_seleccion_modelo/eda.json |
| validation | node | alpha | 1 | 5 | results/04_seleccion_modelo/eda.json |
| validation | node | alpha | 2 | 5 | results/04_seleccion_modelo/eda.json |
| validation | node | alpha | 3 | 8 | results/04_seleccion_modelo/eda.json |
| validation | node | alpha | 4 | 24 | results/04_seleccion_modelo/eda.json |
| validation | node | beta | 0 | 2009 | results/04_seleccion_modelo/eda.json |
| validation | node | beta | 1 | 4 | results/04_seleccion_modelo/eda.json |
| validation | node | beta | 2 | 5 | results/04_seleccion_modelo/eda.json |
| validation | node | beta | 3 | 12 | results/04_seleccion_modelo/eda.json |
| validation | node | beta | 4 | 33 | results/04_seleccion_modelo/eda.json |
| validation | node | gamma | 0 | 1464 | results/04_seleccion_modelo/eda.json |
| validation | node | gamma | 1 | 7 | results/04_seleccion_modelo/eda.json |
| validation | node | gamma | 2 | 4 | results/04_seleccion_modelo/eda.json |
| validation | node | gamma | 3 | 10 | results/04_seleccion_modelo/eda.json |
| validation | node | gamma | 4 | 19 | results/04_seleccion_modelo/eda.json |

## Eda Nodos

| partition | node | vehicles | examples | source_file |
| --- | --- | --- | --- | --- |
| train | alpha | 6735 | 8954 | results/03_cache/train.npz |
| train | beta | 9561 | 12923 | results/03_cache/train.npz |
| train | gamma | 7254 | 9974 | results/03_cache/train.npz |
| validation | alpha | 1479 | 1479 | results/03_cache/validation.npz |
| validation | beta | 2063 | 2063 | results/03_cache/validation.npz |
| validation | gamma | 1504 | 1504 | results/03_cache/validation.npz |

## Eda Eta Cuadrado

| feature | eta_squared | rank | source_file |
| --- | --- | --- | --- |
| 158_5__trend | 0.0506424694423797 | 1 | results/04_seleccion_modelo/eda.json |
| 158_6__trend | 0.049810249069607064 | 2 | results/04_seleccion_modelo/eda.json |
| 397_26__trend | 0.048747636742476605 | 3 | results/04_seleccion_modelo/eda.json |
| 397_2__trend | 0.046615137045262774 | 4 | results/04_seleccion_modelo/eda.json |
| 397_27__trend | 0.043872971283624516 | 5 | results/04_seleccion_modelo/eda.json |
| 397_3__trend | 0.04339289039790534 | 6 | results/04_seleccion_modelo/eda.json |
| 397_33__trend | 0.04232574280650376 | 7 | results/04_seleccion_modelo/eda.json |
| 397_20__trend | 0.04099571501985019 | 8 | results/04_seleccion_modelo/eda.json |
| 171_0__trend | 0.03770849379112661 | 9 | results/04_seleccion_modelo/eda.json |
| 397_4__trend | 0.03760444905926132 | 10 | results/04_seleccion_modelo/eda.json |
| 158_4__trend | 0.037325631752097146 | 11 | results/04_seleccion_modelo/eda.json |
| 835_0__trend | 0.0354884618011312 | 12 | results/04_seleccion_modelo/eda.json |

## Seleccion Modelo

| candidate | hidden_sizes | epochs | batch_size | learning_rate | weight_decay | parameters | mean_cost_mean | mean_cost_sd | macro_f1_mean | macro_f1_sd | balanced_accuracy_mean | balanced_accuracy_sd | macro_pr_auc_mean | macro_pr_auc_sd | rank | selected |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MLP-01 | 64 | 10 | 256 | 0.001 | 0.0001 | 34117 | 8.76376159821523 | 0.1722260605239366 | 0.06427314640163313 | 0.005830990649772772 | 0.22021802170667942 | 0.0024814561674810706 | 0.2974859190821827 | 0.0035324456965260716 | 1 | True |
| MLP-03 | 64 | 10 | 256 | 0.0005 | 0.0001 | 34117 | 8.866197848415347 | 0.13214956747754494 | 0.05171767279330669 | 0.002719095727182826 | 0.21351413831084823 | 0.0011949422492675802 | 0.2988444358851959 | 0.0017643234290184268 | 2 | False |
| MLP-04 | 128x64 | 10 | 256 | 0.0005 | 0.0001 | 76165 | 9.159136586036594 | 0.26650486719584265 | 0.09188830988591719 | 0.01299843579093931 | 0.23511273459034462 | 0.007422842910411448 | 0.29894558806384547 | 0.0029683435523069606 | 3 | False |
| MLP-02 | 128x64 | 10 | 256 | 0.001 | 0.0001 | 76165 | 10.33505560028459 | 0.5485798309201133 | 0.12214685527834732 | 0.0129961267361671 | 0.25216727214297807 | 0.007517884597244168 | 0.2969722218486712 | 0.002891800535624382 | 4 | False |

## Seleccion Variante

| variant | mean_cost_mean | mean_cost_sd | macro_pr_auc_mean | macro_pr_auc_sd | balanced_accuracy_mean | balanced_accuracy_sd | accuracy_mean | accuracy_sd | folds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| a_weighted_cost | 8.455426765151891 | 0.16542046019256182 | 0.256527225444693 | 0.005333754903834454 | 0.22224434256806863 | 0.0027574348252226467 | 0.19078996950878152 | 0.016090996608550193 | 5 |
| b_unweighted_cost | 8.346975427278657 | 0.32630687343042775 | 0.26220703955957136 | 0.004432642663680357 | 0.24701606952939148 | 0.010405653595402154 | 0.31003777849798503 | 0.036618763450587025 | 5 |
| c_weighted_argmax | 37.27319345771106 | 2.334243275716476 | 0.256527225444693 | 0.005333754903834454 | 0.2612776496391268 | 0.044934231778309436 | 0.8543611861489463 | 0.01834464728721431 | 5 |
| d_unweighted_cost_prior | 8.866671639310336 | 0.5753059285105857 | 0.2698156658602634 | 0.0028225291369988544 | 0.2713704970197812 | 0.008318064628192786 | 0.4619818862070761 | 0.05462746669559898 | 5 |

## Referencias Cv

| model | mean_cost_mean | mean_cost_sd | macro_pr_auc_mean | macro_pr_auc_sd | balanced_accuracy_mean | balanced_accuracy_sd | accuracy_mean | accuracy_sd | folds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| hist_gradient_boosting | 8.56449463672684 | 0.16116398227775833 | 0.27027112746484205 | 0.018095237787053423 | 0.21890627161923595 | 0.0049099301874901595 | 0.16968607158154883 | 0.013100823550893172 | 5 |
| logistic_regression | 8.71667794873547 | 0.10921584715706482 | 0.25910307708353936 | 0.0040840263903488515 | 0.21567373118524685 | 0.0016771411290052397 | 0.16190971606764892 | 0.009254600581541301 | 5 |

## Baselines Validation

| baseline | mean_cost | macro_f1 | macro_pr_auc | balanced_accuracy | accuracy | examples | source_file |
| --- | --- | --- | --- | --- | --- | --- | --- |
| always_0 | 11.375346809353944 | 0.19726797910807553 | 0.200560253410901 | 0.2 | 0.9730479587792311 | 5046 | results/08_diagnostico/diagnostics.json |
| always_4 | 9.82282996432818 | 0.005935181569699336 | 0.200560253410901 | 0.2 | 0.015061434799841459 | 5046 | results/08_diagnostico/diagnostics.json |
| train_prior | 9.82282996432818 | 0.005935181569699336 | 0.200560253410901 | 0.2 | 0.015061434799841459 | 5046 | results/08_diagnostico/diagnostics.json |

## Multisemilla Resumen

| regime | metric | mean | sd | ci_95_lower | ci_95_upper | n | source_file |
| --- | --- | --- | --- | --- | --- | --- | --- |
| local | mean_cost | 9.153091557669441 | 0.13280982907815284 | 9.07810097106619 | 9.233076694411416 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| local | macro_f1 | 0.04692985367469697 | 0.012777218782465271 | 0.04051911677521008 | 0.055291545015208644 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| local | macro_pr_auc | 0.21360113575944933 | 0.005944438871390264 | 0.2102190249928904 | 0.21716326883076612 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| local | balanced_accuracy | 0.2144990084682174 | 0.0036115466993977144 | 0.2124038957819702 | 0.2166569326830314 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| local | accuracy | 0.11987713040031708 | 0.04178689887498627 | 0.09960315101070155 | 0.14797859690844234 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| centralized | mean_cost | 9.568866428854538 | 0.10236512989438963 | 9.511533392786365 | 9.628776258422514 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| centralized | macro_f1 | 0.028412279510106386 | 0.010711757068828709 | 0.02253770471804216 | 0.03503767661955434 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| centralized | macro_pr_auc | 0.20947921046593593 | 0.0041290463415671955 | 0.2071739781195864 | 0.21208008294754774 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| centralized | balanced_accuracy | 0.21025929896023152 | 0.005837821016358545 | 0.20698418908779076 | 0.21374618126272912 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| centralized | accuracy | 0.05081252477209671 | 0.009436119092437084 | 0.04550138723741578 | 0.05644074514466905 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedavg | mean_cost | 9.487019421323819 | 0.07831659534459647 | 9.439571938168847 | 9.531273781212843 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedavg | macro_f1 | 0.025068772063572824 | 0.0068420598586927854 | 0.021913018656768885 | 0.029682624489852687 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedavg | macro_pr_auc | 0.21273765415161466 | 0.0019018170056272054 | 0.2115936501120725 | 0.213819825370647 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedavg | balanced_accuracy | 0.20812072569407225 | 0.003657078970623548 | 0.2063835137742523 | 0.21054333261871583 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedavg | accuracy | 0.057332540626238604 | 0.006634269871624065 | 0.05348791121680539 | 0.06121680539040825 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedprox | mean_cost | 9.420630202140309 | 0.08726352680191128 | 9.36615091161316 | 9.468866924296472 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedprox | macro_f1 | 0.023664222819270518 | 0.0026642896148325046 | 0.02211365368211451 | 0.025253629026516202 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedprox | macro_pr_auc | 0.21253763674771128 | 0.0018840368837451612 | 0.21141636726557492 | 0.2136141172000945 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedprox | balanced_accuracy | 0.2078288133776396 | 0.002037572957424072 | 0.20672158055525774 | 0.20909240004287705 | 10 | results/06_aprendizaje/seed_*/metrics.json |
| fedprox | accuracy | 0.05945303210463733 | 0.006970390475302111 | 0.05546967895362663 | 0.0635354736424891 | 10 | results/06_aprendizaje/seed_*/metrics.json |

## Multisemilla Semillas

| seed | regime | mean_cost | macro_f1 | macro_pr_auc | balanced_accuracy | accuracy | examples | source_file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 100 | local | 9.133769322235434 | 0.03802719931874908 | 0.2073320528861366 | 0.214517097223711 | 0.09829567974633373 | 5046 | results/06_aprendizaje/seed_100/metrics.json |
| 100 | centralized | 9.723345223939754 | 0.03575836163692712 | 0.20653435656913127 | 0.21483787115446457 | 0.039239001189060645 | 5046 | results/06_aprendizaje/seed_100/metrics.json |
| 100 | fedavg | 9.581847007530717 | 0.020783258148532702 | 0.2140116283292278 | 0.20498552899560513 | 0.05192231470471661 | 5046 | results/06_aprendizaje/seed_100/metrics.json |
| 100 | fedprox | 9.475426080063416 | 0.02269602461303187 | 0.2142097031766219 | 0.2060038589345053 | 0.05687673404676972 | 5046 | results/06_aprendizaje/seed_100/metrics.json |
| 101 | local | 9.30122869599683 | 0.03325016172108512 | 0.21955576255561932 | 0.20919712723764605 | 0.0850178359096314 | 5046 | results/06_aprendizaje/seed_101/metrics.json |
| 101 | centralized | 9.569758224336107 | 0.017351079977430295 | 0.2101959871828396 | 0.20570264765784113 | 0.04280618311533888 | 5046 | results/06_aprendizaje/seed_101/metrics.json |
| 101 | fedavg | 9.54558065794689 | 0.018468825431525254 | 0.21072449253261832 | 0.20635437881873728 | 0.04597701149425287 | 5046 | results/06_aprendizaje/seed_101/metrics.json |
| 101 | fedprox | 9.476218787158144 | 0.01970680834317198 | 0.21110507355285607 | 0.20700610997963337 | 0.049147839873166864 | 5046 | results/06_aprendizaje/seed_101/metrics.json |
| 102 | local | 9.064803804994055 | 0.04389116489590093 | 0.20936687575114626 | 0.2153885732661593 | 0.11514070550931431 | 5046 | results/06_aprendizaje/seed_102/metrics.json |
| 102 | centralized | 9.49623464130004 | 0.023616564218762383 | 0.21647943997641161 | 0.2064519241076214 | 0.05905667855727309 | 5046 | results/06_aprendizaje/seed_102/metrics.json |
| 102 | fedavg | 9.502179944510504 | 0.023902090271414957 | 0.21233882289951972 | 0.2066555900954014 | 0.06004756242568371 | 5046 | results/06_aprendizaje/seed_102/metrics.json |
| 102 | fedprox | 9.42627824019025 | 0.025405184915846556 | 0.21228842388642036 | 0.20747025404652158 | 0.0640110978993262 | 5046 | results/06_aprendizaje/seed_102/metrics.json |
| 103 | local | 9.270907649623464 | 0.040067211765462754 | 0.2187283316484548 | 0.21055740165076645 | 0.10424098295679746 | 5046 | results/06_aprendizaje/seed_103/metrics.json |
| 103 | centralized | 9.596313912009512 | 0.040924499069982606 | 0.2065862915081626 | 0.21638573266159286 | 0.04676971858898137 | 5046 | results/06_aprendizaje/seed_103/metrics.json |
| 103 | fedavg | 9.538842647641696 | 0.043229997118013855 | 0.21412206615830437 | 0.2176077285882731 | 0.05271502179944511 | 5046 | results/06_aprendizaje/seed_103/metrics.json |
| 103 | fedprox | 9.446294094332144 | 0.021000278960736633 | 0.21284393565352944 | 0.20769857433808553 | 0.05251684502576298 | 5046 | results/06_aprendizaje/seed_103/metrics.json |
| 104 | local | 9.223147047166073 | 0.044931220675481796 | 0.21318499207579805 | 0.21085861292743058 | 0.11831153388822829 | 5046 | results/06_aprendizaje/seed_104/metrics.json |
| 104 | centralized | 9.704320253666271 | 0.01675513795673915 | 0.20667545982195068 | 0.20286740272269266 | 0.041617122473246136 | 5046 | results/06_aprendizaje/seed_104/metrics.json |
| 104 | fedavg | 9.57193816884661 | 0.02129908777122083 | 0.21084713606454358 | 0.20527066137849714 | 0.05330955212049148 | 5046 | results/06_aprendizaje/seed_104/metrics.json |
| 104 | fedprox | 9.53448275862069 | 0.02129958411476497 | 0.210508467643954 | 0.20527066137849714 | 0.05330955212049148 | 5046 | results/06_aprendizaje/seed_104/metrics.json |
| 105 | local | 8.987118509710662 | 0.07836730891518426 | 0.20927579585832135 | 0.21743166470146855 | 0.2259215219976219 | 5046 | results/06_aprendizaje/seed_105/metrics.json |
| 105 | centralized | 9.455410225921522 | 0.026362588464189353 | 0.2084286776669662 | 0.20791831921963766 | 0.06619104240982956 | 5046 | results/06_aprendizaje/seed_105/metrics.json |
| 105 | fedavg | 9.377526753864448 | 0.02497147666458604 | 0.21378356250357378 | 0.20981670061099797 | 0.06282203725723345 | 5046 | results/06_aprendizaje/seed_105/metrics.json |
| 105 | fedprox | 9.309155766944114 | 0.026104202234122242 | 0.2152596208084577 | 0.21042769857433807 | 0.06579468886246533 | 5046 | results/06_aprendizaje/seed_105/metrics.json |
| 106 | local | 9.070947284978201 | 0.03822507203950503 | 0.22109095618199898 | 0.214639296816379 | 0.09889021006738011 | 5046 | results/06_aprendizaje/seed_106/metrics.json |
| 106 | centralized | 9.552913198573128 | 0.021941590886961425 | 0.2140536690784911 | 0.2055965269589452 | 0.05489496630994847 | 5046 | results/06_aprendizaje/seed_106/metrics.json |
| 106 | fedavg | 9.516250495441934 | 0.023306210599803857 | 0.2148738829681996 | 0.20632972451495335 | 0.05846214823622672 | 5046 | results/06_aprendizaje/seed_106/metrics.json |
| 106 | fedprox | 9.48612762584225 | 0.023072958566775367 | 0.21201624322910234 | 0.20620752492228536 | 0.05786761791518034 | 5046 | results/06_aprendizaje/seed_106/metrics.json |
| 107 | local | 9.085017835909632 | 0.04650473125361009 | 0.22094862088161676 | 0.2143863222210312 | 0.12286959968291716 | 5046 | results/06_aprendizaje/seed_107/metrics.json |
| 107 | centralized | 9.519817677368213 | 0.020035692044443797 | 0.21464362648743757 | 0.20716904276985743 | 0.04994054696789536 | 5046 | results/06_aprendizaje/seed_107/metrics.json |
| 107 | fedavg | 9.402893380895758 | 0.02255189993601437 | 0.2092412186558529 | 0.2085132382892057 | 0.05648038049940547 | 5046 | results/06_aprendizaje/seed_107/metrics.json |
| 107 | fedprox | 9.372968688069758 | 0.02375756201737351 | 0.20933551658012645 | 0.20916496945010182 | 0.05965120887831946 | 5046 | results/06_aprendizaje/seed_107/metrics.json |
| 108 | local | 9.380103051922315 | 0.05156452629468729 | 0.20570311997227972 | 0.22128979526208598 | 0.08323424494649227 | 5046 | results/06_aprendizaje/seed_108/metrics.json |
| 108 | centralized | 9.654181529924692 | 0.032838137623504945 | 0.20589986997734083 | 0.2159784006860328 | 0.04478795085216013 | 5046 | results/06_aprendizaje/seed_108/metrics.json |
| 108 | fedavg | 9.454022988505747 | 0.024975846405000786 | 0.2145613922713648 | 0.20722585486118553 | 0.06282203725723345 | 5046 | results/06_aprendizaje/seed_108/metrics.json |
| 108 | fedprox | 9.431034482758621 | 0.0251275822214229 | 0.21466382216086055 | 0.20730732125629756 | 0.06321839080459771 | 5046 | results/06_aprendizaje/seed_108/metrics.json |
| 109 | local | 9.01387237415775 | 0.05446993986730333 | 0.21082484978312133 | 0.21672419337549576 | 0.14684898929845422 | 5046 | results/06_aprendizaje/seed_109/metrics.json |
| 109 | centralized | 9.416369401506143 | 0.04853914322212285 | 0.20529472639062782 | 0.21968512166362952 | 0.06282203725723345 | 5046 | results/06_aprendizaje/seed_109/metrics.json |
| 109 | fedavg | 9.379112168053904 | 0.02719902828961559 | 0.21287233913294176 | 0.20844785078786582 | 0.06876734046769718 | 5046 | results/06_aprendizaje/seed_109/metrics.json |
| 109 | fedprox | 9.248315497423702 | 0.02847204220545917 | 0.21314556078518415 | 0.21173116089613037 | 0.07213634562029331 | 5046 | results/06_aprendizaje/seed_109/metrics.json |

## Local Por Nodo

| seed | node | mean_cost | macro_f1 | macro_pr_auc | balanced_accuracy | accuracy | examples | source_file |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 100 | alpha | 8.98106828938472 | 0.04478949870106066 | 0.21069346020447463 | 0.22073764787752262 | 0.1169709263015551 | 1479 | results/06_aprendizaje/seed_100/metrics.json |
| 100 | beta | 9.368880271449346 | 0.023949874686716794 | 0.2084134561672058 | 0.20905923344947736 | 0.060106640814348036 | 2063 | results/06_aprendizaje/seed_100/metrics.json |
| 100 | gamma | 8.961436170212766 | 0.049403026421532194 | 0.21383773664779682 | 0.21420046016681046 | 0.13231382978723405 | 1504 | results/06_aprendizaje/seed_100/metrics.json |
| 101 | alpha | 9.30290736984449 | 0.04492558126298415 | 0.20957736898030918 | 0.21268267223382048 | 0.11764705882352941 | 1479 | results/06_aprendizaje/seed_101/metrics.json |
| 101 | beta | 9.519631604459525 | 0.017949882307632614 | 0.25726112304068394 | 0.20587356893977105 | 0.04459524963645177 | 2063 | results/06_aprendizaje/seed_101/metrics.json |
| 101 | gamma | 9.0 | 0.041337462080718805 | 0.2137915534590343 | 0.2092824273799252 | 0.10837765957446809 | 1504 | results/06_aprendizaje/seed_101/metrics.json |
| 102 | alpha | 8.741717376605814 | 0.06385326167124956 | 0.20833181804571982 | 0.22465205288796103 | 0.1757944557133198 | 1479 | results/06_aprendizaje/seed_102/metrics.json |
| 102 | beta | 9.213281628696073 | 0.029506149607476995 | 0.25921105704444797 | 0.21204579392732703 | 0.07464857004362578 | 2063 | results/06_aprendizaje/seed_102/metrics.json |
| 102 | gamma | 9.178856382978724 | 0.042205482090360374 | 0.2176313113002984 | 0.2098288754673569 | 0.1110372340425532 | 1504 | results/06_aprendizaje/seed_102/metrics.json |
| 103 | alpha | 8.710615280594997 | 0.07440988265315987 | 0.20815104624796565 | 0.22369519832985385 | 0.21095334685598377 | 1479 | results/06_aprendizaje/seed_103/metrics.json |
| 103 | beta | 9.409112942317014 | 0.0224568072268465 | 0.25910450993344 | 0.2082628173220508 | 0.05622879301987397 | 2063 | results/06_aprendizaje/seed_103/metrics.json |
| 103 | gamma | 9.632313829787234 | 0.02574342065091286 | 0.2107656343696394 | 0.20040264595916019 | 0.06515957446808511 | 1504 | results/06_aprendizaje/seed_103/metrics.json |
| 104 | alpha | 8.96078431372549 | 0.076412393591771 | 0.20753227399802743 | 0.2170320111343076 | 0.21839080459770116 | 1479 | results/06_aprendizaje/seed_104/metrics.json |
| 104 | beta | 9.345128453708192 | 0.02454588682834047 | 0.2355326016736464 | 0.2093578894972623 | 0.06156083373727581 | 2063 | results/06_aprendizaje/seed_104/metrics.json |
| 104 | gamma | 9.313829787234043 | 0.03755497803588511 | 0.21256496917214193 | 0.20709663503019843 | 0.09773936170212766 | 1504 | results/06_aprendizaje/seed_104/metrics.json |
| 105 | alpha | 9.369844489519945 | 0.12147603034585833 | 0.20876985228325032 | 0.22155532359081417 | 0.3995943204868154 | 1479 | results/06_aprendizaje/seed_105/metrics.json |
| 105 | beta | 8.961706253029568 | 0.05450388501868897 | 0.2107304635002108 | 0.2148573841953633 | 0.14638875424139602 | 2063 | results/06_aprendizaje/seed_105/metrics.json |
| 105 | gamma | 8.64561170212766 | 0.059676312368211915 | 0.22116615451968613 | 0.2207578372159908 | 0.16422872340425532 | 1504 | results/06_aprendizaje/seed_105/metrics.json |
| 106 | alpha | 8.35970250169033 | 0.05877860405334068 | 0.21026480680945037 | 0.22936673625608908 | 0.15889114266396215 | 1479 | results/06_aprendizaje/seed_106/metrics.json |
| 106 | beta | 9.398933591856519 | 0.022823693587037962 | 0.26167137105331667 | 0.2084619213539074 | 0.057198254968492485 | 2063 | results/06_aprendizaje/seed_106/metrics.json |
| 106 | gamma | 9.320478723404255 | 0.0373242005046376 | 0.21450181941098223 | 0.20696002300834052 | 0.09707446808510638 | 1504 | results/06_aprendizaje/seed_106/metrics.json |
| 107 | alpha | 8.678837052062205 | 0.07523996802371381 | 0.22150842449013314 | 0.2242519137091162 | 0.213657876943881 | 1479 | results/06_aprendizaje/seed_107/metrics.json |
| 107 | beta | 9.430441105186622 | 0.021536514895460636 | 0.2599740833456802 | 0.20776505724240915 | 0.05380513814832768 | 2063 | results/06_aprendizaje/seed_107/metrics.json |
| 107 | gamma | 9.01063829787234 | 0.0480360866805694 | 0.21464649324439655 | 0.21338078803566293 | 0.1283244680851064 | 1504 | results/06_aprendizaje/seed_107/metrics.json |
| 108 | alpha | 9.168356997971603 | 0.04955052427703199 | 0.21670352457709474 | 0.21546624913013224 | 0.13116970926301555 | 1479 | results/06_aprendizaje/seed_108/metrics.json |
| 108 | beta | 9.296655356277267 | 0.10638135986153523 | 0.2079088785205257 | 0.2603534096565455 | 0.06689287445467765 | 2063 | results/06_aprendizaje/seed_108/metrics.json |
| 108 | gamma | 9.70279255319149 | 0.023220295457310063 | 0.20983192766296796 | 0.19903652574058095 | 0.05851063829787234 | 1504 | results/06_aprendizaje/seed_108/metrics.json |
| 109 | alpha | 8.668018931710614 | 0.09165162749780068 | 0.20810392130938649 | 0.2283054975643702 | 0.27315753887762 | 1479 | results/06_aprendizaje/seed_109/metrics.json |
| 109 | beta | 9.142995637421231 | 0.03233649894631614 | 0.23383818413935908 | 0.21363862618218019 | 0.08240426563257393 | 2063 | results/06_aprendizaje/seed_109/metrics.json |
| 109 | gamma | 9.17686170212766 | 0.04221323332732861 | 0.21386514501244075 | 0.2098288754673569 | 0.1110372340425532 | 1504 | results/06_aprendizaje/seed_109/metrics.json |

## Estadistica Primaria

| reference | candidate | metric | mean_difference | ci_95_lower | ci_95_upper | wilcoxon_statistic | p_value | rank_biserial | nonzero_pairs | test_method | p_value_holm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| local | fedavg | mean_cost | 0.3339278636543792 | 0.26074118113357037 | 0.395461751882679 | 0.0 | 0.001953125 | 1.0 | 10 | exact | 0.009765625 |
| local | fedprox | mean_cost | 0.2675386444708675 | 0.20005895759016978 | 0.3275673801030512 | 0.0 | 0.001953125 | 1.0 | 10 | exact | 0.009765625 |
| centralized | fedavg | mean_cost | -0.08184700753071752 | -0.12045233848593014 | -0.0452011494252869 | 1.0 | 0.00390625 | -0.9636363636363636 | 10 | exact | 0.009765625 |
| centralized | fedprox | mean_cost | -0.14823622671422926 | -0.18351169242964732 | -0.11293896155370625 | 0.0 | 0.001953125 | -1.0 | 10 | exact | 0.009765625 |
| fedavg | fedprox | mean_cost | -0.06638921918351173 | -0.08810939357907249 | -0.045698573127229455 | 0.0 | 0.001953125 | -1.0 | 10 | exact | 0.009765625 |

## Estadistica Secundaria

| reference | candidate | metric | mean_difference | ci_95_lower | ci_95_upper | wilcoxon_statistic | p_value | rank_biserial | nonzero_pairs | test_method |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| local | fedavg | macro_pr_auc | -0.0008634816078346514 | -0.00505545347945367 | 0.0031983368311557527 | 24.0 | 0.76953125 | -0.12727272727272726 | 10 | exact |
| local | fedavg | balanced_accuracy | -0.0063782827741451446 | -0.009256243970414826 | -0.002771730624933016 | 4.0 | 0.013671875 | -0.8545454545454545 | 10 | exact |
| local | fedavg | accuracy | -0.06254458977407848 | -0.08824861276258421 | -0.04389466904478797 | 0.0 | 0.001953125 | -1.0 | 10 | exact |
| local | fedprox | macro_pr_auc | -0.0010634990117380171 | -0.00549063047155473 | 0.003267813483303378 | 23.0 | 0.6953125 | -0.16363636363636364 | 10 | exact |
| local | fedprox | balanced_accuracy | -0.0066701950905777765 | -0.008780249758816605 | -0.004829575115232091 | 0.0 | 0.001953125 | -1.0 | 10 | exact |
| local | fedprox | accuracy | -0.060424098295679754 | -0.08529577883472059 | -0.041834621482362264 | 0.0 | 0.001953125 | -1.0 | 10 | exact |
| centralized | fedavg | macro_pr_auc | 0.003258443685678733 | 0.0002141547201239424 | 0.006082655910040133 | 9.0 | 0.064453125 | 0.6727272727272727 | 10 | exact |
| centralized | fedavg | balanced_accuracy | -0.00213857326615928 | -0.0055977596741344 | 0.0009067826133561966 | 27.0 | 1.0 | 0.01818181818181818 | 10 | exact |
| centralized | fedavg | accuracy | 0.006520015854141895 | 0.00307173999207293 | 0.010146650812524773 | 3.0 | 0.009765625 | 0.8909090909090909 | 10 | exact |
| centralized | fedprox | macro_pr_auc | 0.0030584262817753673 | -0.00017162229232864368 | 0.006093315833175473 | 11.0 | 0.10546875 | 0.6 | 10 | exact |
| centralized | fedprox | balanced_accuracy | -0.0024304855825919127 | -0.005551666845321046 | 0.0006302658377103645 | 21.0 | 0.556640625 | -0.23636363636363636 | 10 | exact |
| centralized | fedprox | accuracy | 0.008640507332540629 | 0.005192231470471662 | 0.01232659532302814 | 1.0 | 0.00390625 | 0.9636363636363636 | 10 | exact |
| fedavg | fedprox | macro_pr_auc | -0.00020001740390336586 | -0.0009269886724743839 | 0.0004043534015766345 | 25.0 | 0.845703125 | 0.09090909090909091 | 10 | exact |
| fedavg | fedprox | balanced_accuracy | -0.0002919123164326326 | -0.0026469671186622303 | 0.0012579456533390481 | 11.0 | 0.203125 | 0.5111111111111111 | 9 | exact |
| fedavg | fedprox | accuracy | 0.0021204914783987325 | 0.0009314308363059839 | 0.0032699167657550534 | 4.0 | 0.03281585897343788 | 0.8222222222222222 | 9 | normal |

## Confusion

| regime | actual_class | predicted_class | examples | source_file |
| --- | --- | --- | --- | --- |
| local | 0 | 0 | 421 | results/08_diagnostico/diagnostics.json |
| local | 0 | 1 | 2 | results/08_diagnostico/diagnostics.json |
| local | 0 | 2 | 7 | results/08_diagnostico/diagnostics.json |
| local | 0 | 3 | 38 | results/08_diagnostico/diagnostics.json |
| local | 0 | 4 | 4442 | results/08_diagnostico/diagnostics.json |
| local | 1 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| local | 1 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| local | 1 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| local | 1 | 3 | 1 | results/08_diagnostico/diagnostics.json |
| local | 1 | 4 | 15 | results/08_diagnostico/diagnostics.json |
| local | 2 | 0 | 1 | results/08_diagnostico/diagnostics.json |
| local | 2 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| local | 2 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| local | 2 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| local | 2 | 4 | 13 | results/08_diagnostico/diagnostics.json |
| local | 3 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| local | 3 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| local | 3 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| local | 3 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| local | 3 | 4 | 30 | results/08_diagnostico/diagnostics.json |
| local | 4 | 0 | 1 | results/08_diagnostico/diagnostics.json |
| local | 4 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| local | 4 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| local | 4 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| local | 4 | 4 | 75 | results/08_diagnostico/diagnostics.json |
| centralized | 0 | 0 | 122 | results/08_diagnostico/diagnostics.json |
| centralized | 0 | 1 | 3 | results/08_diagnostico/diagnostics.json |
| centralized | 0 | 2 | 9 | results/08_diagnostico/diagnostics.json |
| centralized | 0 | 3 | 38 | results/08_diagnostico/diagnostics.json |
| centralized | 0 | 4 | 4738 | results/08_diagnostico/diagnostics.json |
| centralized | 1 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 1 | 1 | 1 | results/08_diagnostico/diagnostics.json |
| centralized | 1 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 1 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 1 | 4 | 15 | results/08_diagnostico/diagnostics.json |
| centralized | 2 | 0 | 1 | results/08_diagnostico/diagnostics.json |
| centralized | 2 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 2 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 2 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 2 | 4 | 13 | results/08_diagnostico/diagnostics.json |
| centralized | 3 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 3 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 3 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 3 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 3 | 4 | 30 | results/08_diagnostico/diagnostics.json |
| centralized | 4 | 0 | 1 | results/08_diagnostico/diagnostics.json |
| centralized | 4 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 4 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 4 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| centralized | 4 | 4 | 75 | results/08_diagnostico/diagnostics.json |
| fedavg | 0 | 0 | 187 | results/08_diagnostico/diagnostics.json |
| fedavg | 0 | 1 | 1 | results/08_diagnostico/diagnostics.json |
| fedavg | 0 | 2 | 9 | results/08_diagnostico/diagnostics.json |
| fedavg | 0 | 3 | 16 | results/08_diagnostico/diagnostics.json |
| fedavg | 0 | 4 | 4697 | results/08_diagnostico/diagnostics.json |
| fedavg | 1 | 0 | 1 | results/08_diagnostico/diagnostics.json |
| fedavg | 1 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 1 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 1 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 1 | 4 | 15 | results/08_diagnostico/diagnostics.json |
| fedavg | 2 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 2 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 2 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 2 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 2 | 4 | 14 | results/08_diagnostico/diagnostics.json |
| fedavg | 3 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 3 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 3 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 3 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 3 | 4 | 30 | results/08_diagnostico/diagnostics.json |
| fedavg | 4 | 0 | 1 | results/08_diagnostico/diagnostics.json |
| fedavg | 4 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 4 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 4 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedavg | 4 | 4 | 75 | results/08_diagnostico/diagnostics.json |
| fedprox | 0 | 0 | 212 | results/08_diagnostico/diagnostics.json |
| fedprox | 0 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 0 | 2 | 10 | results/08_diagnostico/diagnostics.json |
| fedprox | 0 | 3 | 13 | results/08_diagnostico/diagnostics.json |
| fedprox | 0 | 4 | 4675 | results/08_diagnostico/diagnostics.json |
| fedprox | 1 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 1 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 1 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 1 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 1 | 4 | 16 | results/08_diagnostico/diagnostics.json |
| fedprox | 2 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 2 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 2 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 2 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 2 | 4 | 14 | results/08_diagnostico/diagnostics.json |
| fedprox | 3 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 3 | 1 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 3 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 3 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 3 | 4 | 30 | results/08_diagnostico/diagnostics.json |
| fedprox | 4 | 0 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 4 | 1 | 1 | results/08_diagnostico/diagnostics.json |
| fedprox | 4 | 2 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 4 | 3 | 0 | results/08_diagnostico/diagnostics.json |
| fedprox | 4 | 4 | 75 | results/08_diagnostico/diagnostics.json |

## Metricas Por Clase

| regime | class | precision | recall | f1 | support | source_file |
| --- | --- | --- | --- | --- | --- | --- |
| local | 0 | 0.9952718676122931 | 0.08574338085539715 | 0.15788486780423777 | 4910 | results/08_diagnostico/diagnostics.json |
| local | 1 | 0.0 | 0.0 | 0.0 | 16 | results/08_diagnostico/diagnostics.json |
| local | 2 | 0.0 | 0.0 | 0.0 | 14 | results/08_diagnostico/diagnostics.json |
| local | 3 | 0.0 | 0.0 | 0.0 | 30 | results/08_diagnostico/diagnostics.json |
| local | 4 | 0.01639344262295082 | 0.9868421052631579 | 0.03225112878950764 | 76 | results/08_diagnostico/diagnostics.json |
| centralized | 0 | 0.9838709677419355 | 0.02484725050916497 | 0.04847040127135478 | 4910 | results/08_diagnostico/diagnostics.json |
| centralized | 1 | 0.25 | 0.0625 | 0.1 | 16 | results/08_diagnostico/diagnostics.json |
| centralized | 2 | 0.0 | 0.0 | 0.0 | 14 | results/08_diagnostico/diagnostics.json |
| centralized | 3 | 0.0 | 0.0 | 0.0 | 30 | results/08_diagnostico/diagnostics.json |
| centralized | 4 | 0.015397249024840895 | 0.9868421052631579 | 0.030321406913280773 | 76 | results/08_diagnostico/diagnostics.json |
| fedavg | 0 | 0.9894179894179894 | 0.03808553971486762 | 0.07334771523828201 | 4910 | results/08_diagnostico/diagnostics.json |
| fedavg | 1 | 0.0 | 0.0 | 0.0 | 16 | results/08_diagnostico/diagnostics.json |
| fedavg | 2 | 0.0 | 0.0 | 0.0 | 14 | results/08_diagnostico/diagnostics.json |
| fedavg | 3 | 0.0 | 0.0 | 0.0 | 30 | results/08_diagnostico/diagnostics.json |
| fedavg | 4 | 0.015524736079486649 | 0.9868421052631579 | 0.030568575504381496 | 76 | results/08_diagnostico/diagnostics.json |
| fedprox | 0 | 1.0 | 0.043177189409368634 | 0.0827801639984381 | 4910 | results/08_diagnostico/diagnostics.json |
| fedprox | 1 | 0.0 | 0.0 | 0.0 | 16 | results/08_diagnostico/diagnostics.json |
| fedprox | 2 | 0.0 | 0.0 | 0.0 | 14 | results/08_diagnostico/diagnostics.json |
| fedprox | 3 | 0.0 | 0.0 | 0.0 | 30 | results/08_diagnostico/diagnostics.json |
| fedprox | 4 | 0.015592515592515593 | 0.9868421052631579 | 0.03069995906672125 | 76 | results/08_diagnostico/diagnostics.json |

## Perdidas Cliente Ronda

| seed | regime | round | node | training_loss |
| --- | --- | --- | --- | --- |
| 100 | fedavg | 1 | alpha | 0.9833548752649677 |
| 100 | fedavg | 1 | beta | 0.9781227269787395 |
| 100 | fedavg | 1 | gamma | 1.0198958695520493 |
| 100 | fedavg | 2 | alpha | 0.8212373100382584 |
| 100 | fedavg | 2 | beta | 0.8581105512767572 |
| 100 | fedavg | 2 | gamma | 0.8861345431239088 |
| 100 | fedavg | 3 | alpha | 0.79803610212813 |
| 100 | fedavg | 3 | beta | 0.84256818795789 |
| 100 | fedavg | 3 | gamma | 0.8619472394253463 |
| 100 | fedavg | 4 | alpha | 0.7857272072325121 |
| 100 | fedavg | 4 | beta | 0.8278370315857202 |
| 100 | fedavg | 4 | gamma | 0.852147429123751 |
| 100 | fedavg | 5 | alpha | 0.777112569770617 |
| 100 | fedavg | 5 | beta | 0.8200415816043614 |
| 100 | fedavg | 5 | gamma | 0.843402512128018 |
| 100 | fedavg | 6 | alpha | 0.770269804416769 |
| 100 | fedavg | 6 | beta | 0.8116110928064344 |
| 100 | fedavg | 6 | gamma | 0.8378839032645691 |
| 100 | fedavg | 7 | alpha | 0.7675427477062081 |
| 100 | fedavg | 7 | beta | 0.8055788881037245 |
| 100 | fedavg | 7 | gamma | 0.8327098143872838 |
| 100 | fedavg | 8 | alpha | 0.762852101140132 |
| 100 | fedavg | 8 | beta | 0.8001962893981273 |
| 100 | fedavg | 8 | gamma | 0.8291841804897567 |
| 100 | fedavg | 9 | alpha | 0.7564141454376065 |
| 100 | fedavg | 9 | beta | 0.7960011307820349 |
| 100 | fedavg | 9 | gamma | 0.8233947444946942 |
| 100 | fedavg | 10 | alpha | 0.7512321584267837 |
| 100 | fedavg | 10 | beta | 0.7915974432106847 |
| 100 | fedavg | 10 | gamma | 0.8205133979631757 |
| 100 | fedprox | 1 | alpha | 0.9935249849598083 |
| 100 | fedprox | 1 | beta | 0.9904012420058832 |
| 100 | fedprox | 1 | gamma | 1.0298729584215638 |
| 100 | fedprox | 2 | alpha | 0.8238765995018392 |
| 100 | fedprox | 2 | beta | 0.8613892766811858 |
| 100 | fedprox | 2 | gamma | 0.8883490133242495 |
| 100 | fedprox | 3 | alpha | 0.8008441514726033 |
| 100 | fedprox | 3 | beta | 0.8455762641077338 |
| 100 | fedprox | 3 | gamma | 0.8638213302918467 |
| 100 | fedprox | 4 | alpha | 0.7881082406873705 |
| 100 | fedprox | 4 | beta | 0.8313611223999675 |
| 100 | fedprox | 4 | gamma | 0.853206707930694 |
| 100 | fedprox | 5 | alpha | 0.779369340441923 |
| 100 | fedprox | 5 | beta | 0.8225937146414712 |
| 100 | fedprox | 5 | gamma | 0.8449939474424619 |
| 100 | fedprox | 6 | alpha | 0.7722099744930101 |
| 100 | fedprox | 6 | beta | 0.8145235526038703 |
| 100 | fedprox | 6 | gamma | 0.8396017622895104 |
| 100 | fedprox | 7 | alpha | 0.7701620293670076 |
| 100 | fedprox | 7 | beta | 0.808509903819183 |
| 100 | fedprox | 7 | gamma | 0.8340882090640637 |
| 100 | fedprox | 8 | alpha | 0.7652412327586846 |
| 100 | fedprox | 8 | beta | 0.803582683243656 |
| 100 | fedprox | 8 | gamma | 0.830046367999043 |
| 100 | fedprox | 9 | alpha | 0.758125752297155 |
| 100 | fedprox | 9 | beta | 0.799267475416645 |
| 100 | fedprox | 9 | gamma | 0.8250185670153708 |
| 100 | fedprox | 10 | alpha | 0.7529512554480344 |
| 100 | fedprox | 10 | beta | 0.7950576772162542 |
| 100 | fedprox | 10 | gamma | 0.8215493395377764 |
| 101 | fedavg | 1 | alpha | 0.9962227900086276 |
| 101 | fedavg | 1 | beta | 0.98431922887064 |
| 101 | fedavg | 1 | gamma | 1.0363225177100743 |
| 101 | fedavg | 2 | alpha | 0.829442683556582 |
| 101 | fedavg | 2 | beta | 0.8593880837199619 |
| 101 | fedavg | 2 | gamma | 0.8889098448889132 |
| 101 | fedavg | 3 | alpha | 0.8032177255599393 |
| 101 | fedavg | 3 | beta | 0.8402702039511112 |
| 101 | fedavg | 3 | gamma | 0.8646366564429593 |
| 101 | fedavg | 4 | alpha | 0.7884863334919476 |
| 101 | fedavg | 4 | beta | 0.8256934531552499 |
| 101 | fedavg | 4 | gamma | 0.8500634207738911 |
| 101 | fedavg | 5 | alpha | 0.7801056809262397 |
| 101 | fedavg | 5 | beta | 0.8190160932015461 |
| 101 | fedavg | 5 | gamma | 0.8426393243241984 |
| 101 | fedavg | 6 | alpha | 0.7725702356434785 |
| 101 | fedavg | 6 | beta | 0.8095467045360109 |
| 101 | fedavg | 6 | gamma | 0.8368392654236892 |
| 101 | fedavg | 7 | alpha | 0.7646190424782372 |
| 101 | fedavg | 7 | beta | 0.8037853545747028 |
| 101 | fedavg | 7 | gamma | 0.830680394330435 |
| 101 | fedavg | 8 | alpha | 0.7623375218335822 |
| 101 | fedavg | 8 | beta | 0.7994150021658643 |
| 101 | fedavg | 8 | gamma | 0.8288453758802733 |
| 101 | fedavg | 9 | alpha | 0.7588058863603193 |
| 101 | fedavg | 9 | beta | 0.7953954960718194 |
| 101 | fedavg | 9 | gamma | 0.823867816580353 |
| 101 | fedavg | 10 | alpha | 0.7527034195480747 |
| 101 | fedavg | 10 | beta | 0.7880905355027537 |
| 101 | fedavg | 10 | gamma | 0.8179460204577479 |
| 101 | fedprox | 1 | alpha | 1.0062822244889986 |
| 101 | fedprox | 1 | beta | 0.9963239509513446 |
| 101 | fedprox | 1 | gamma | 1.0461820836222098 |
| 101 | fedprox | 2 | alpha | 0.8319613158583029 |
| 101 | fedprox | 2 | beta | 0.8627622856136669 |
| 101 | fedprox | 2 | gamma | 0.8913440845379352 |
| 101 | fedprox | 3 | alpha | 0.8053692537731216 |
| 101 | fedprox | 3 | beta | 0.8428708250139055 |
| 101 | fedprox | 3 | gamma | 0.8671268387861043 |
| 101 | fedprox | 4 | alpha | 0.7907810404494002 |
| 101 | fedprox | 4 | beta | 0.828323402839632 |
| 101 | fedprox | 4 | gamma | 0.8524138852401131 |
| 101 | fedprox | 5 | alpha | 0.7820989214631099 |
| 101 | fedprox | 5 | beta | 0.8215440870585903 |
| 101 | fedprox | 5 | gamma | 0.8440441270139429 |
| 101 | fedprox | 6 | alpha | 0.7751664868257448 |
| 101 | fedprox | 6 | beta | 0.8121873014465645 |
| 101 | fedprox | 6 | gamma | 0.837813882065699 |
| 101 | fedprox | 7 | alpha | 0.7676662413009395 |
| 101 | fedprox | 7 | beta | 0.8063859379735236 |
| 101 | fedprox | 7 | gamma | 0.8331051318373449 |
| 101 | fedprox | 8 | alpha | 0.7648961697275521 |
| 101 | fedprox | 8 | beta | 0.8020030872875126 |
| 101 | fedprox | 8 | gamma | 0.8305810740124565 |
| 101 | fedprox | 9 | alpha | 0.7614742952290992 |
| 101 | fedprox | 9 | beta | 0.7978405574799174 |
| 101 | fedprox | 9 | gamma | 0.8256769409059211 |
| 101 | fedprox | 10 | alpha | 0.7547573273352861 |
| 101 | fedprox | 10 | beta | 0.7910691941060269 |
| 101 | fedprox | 10 | gamma | 0.8207736301092243 |
| 102 | fedavg | 1 | alpha | 1.0851510813493455 |
| 102 | fedavg | 1 | beta | 1.044044993983272 |
| 102 | fedavg | 1 | gamma | 1.0974290644642057 |
| 102 | fedavg | 2 | alpha | 0.8404866736436333 |
| 102 | fedavg | 2 | beta | 0.8708136311802787 |
| 102 | fedavg | 2 | gamma | 0.9028088176133328 |
| 102 | fedavg | 3 | alpha | 0.8091866009225264 |
| 102 | fedavg | 3 | beta | 0.8457835267490991 |
| 102 | fedavg | 3 | gamma | 0.8713900780591741 |
| 102 | fedavg | 4 | alpha | 0.7942777627383009 |
| 102 | fedavg | 4 | beta | 0.832134600017016 |
| 102 | fedavg | 4 | gamma | 0.8556141002469343 |
| 102 | fedavg | 5 | alpha | 0.7809489975823392 |
| 102 | fedavg | 5 | beta | 0.8218520569153764 |
| 102 | fedavg | 5 | gamma | 0.8454159671638302 |
| 102 | fedavg | 6 | alpha | 0.7752791055084367 |
| 102 | fedavg | 6 | beta | 0.8151665736137691 |
| 102 | fedavg | 6 | gamma | 0.8391416349175795 |
| 102 | fedavg | 7 | alpha | 0.7718347616032721 |
| 102 | fedavg | 7 | beta | 0.8090017953958063 |
| 102 | fedavg | 7 | gamma | 0.8336360345557048 |
| 102 | fedavg | 8 | alpha | 0.761388149129937 |
| 102 | fedavg | 8 | beta | 0.8032009323379586 |
| 102 | fedavg | 8 | gamma | 0.8291677940649572 |
| 102 | fedavg | 9 | alpha | 0.7593403124558971 |
| 102 | fedavg | 9 | beta | 0.7980632877456859 |
| 102 | fedavg | 9 | gamma | 0.8226289893406198 |
| 102 | fedavg | 10 | alpha | 0.755506284167145 |
| 102 | fedavg | 10 | beta | 0.7924800981246936 |
| 102 | fedavg | 10 | gamma | 0.8220510110841717 |
| 102 | fedprox | 1 | alpha | 1.0961569636054995 |
| 102 | fedprox | 1 | beta | 1.0578634299831955 |
| 102 | fedprox | 1 | gamma | 1.1084189008131806 |
| 102 | fedprox | 2 | alpha | 0.843230972671871 |
| 102 | fedprox | 2 | beta | 0.8746925929581004 |
| 102 | fedprox | 2 | gamma | 0.9048000729727033 |
| 102 | fedprox | 3 | alpha | 0.8118428898251746 |
| 102 | fedprox | 3 | beta | 0.8490528556240294 |
| 102 | fedprox | 3 | gamma | 0.8738913751207852 |
| 102 | fedprox | 4 | alpha | 0.796777088793362 |
| 102 | fedprox | 4 | beta | 0.8355511451047944 |
| 102 | fedprox | 4 | gamma | 0.8579098900310592 |
| 102 | fedprox | 5 | alpha | 0.7830998455410374 |
| 102 | fedprox | 5 | beta | 0.8250645628140031 |
| 102 | fedprox | 5 | gamma | 0.8476092375804457 |
| 102 | fedprox | 6 | alpha | 0.7771328506470792 |
| 102 | fedprox | 6 | beta | 0.8186056702431995 |
| 102 | fedprox | 6 | gamma | 0.8409736182279952 |
| 102 | fedprox | 7 | alpha | 0.7730972259497839 |
| 102 | fedprox | 7 | beta | 0.8118976442278663 |
| 102 | fedprox | 7 | gamma | 0.8357729193369229 |
| 102 | fedprox | 8 | alpha | 0.762868692200179 |
| 102 | fedprox | 8 | beta | 0.8061890414576038 |
| 102 | fedprox | 8 | gamma | 0.8313429172755674 |
| 102 | fedprox | 9 | alpha | 0.7614623512544348 |
| 102 | fedprox | 9 | beta | 0.8014368185694074 |
| 102 | fedprox | 9 | gamma | 0.8243928218691053 |
| 102 | fedprox | 10 | alpha | 0.7575574645059887 |
| 102 | fedprox | 10 | beta | 0.7954585659405233 |
| 102 | fedprox | 10 | gamma | 0.8234980815944247 |
| 103 | fedavg | 1 | alpha | 1.03650559848085 |
| 103 | fedavg | 1 | beta | 1.005478193878362 |
| 103 | fedavg | 1 | gamma | 1.058602336726161 |
| 103 | fedavg | 2 | alpha | 0.8282686767765579 |
| 103 | fedavg | 2 | beta | 0.8644081658275745 |
| 103 | fedavg | 2 | gamma | 0.8919386714069404 |
| 103 | fedavg | 3 | alpha | 0.802896912938813 |
| 103 | fedavg | 3 | beta | 0.8411041438132167 |
| 103 | fedavg | 3 | gamma | 0.8660965436012157 |
| 103 | fedavg | 4 | alpha | 0.7888909215529849 |
| 103 | fedavg | 4 | beta | 0.8302816479722477 |
| 103 | fedavg | 4 | gamma | 0.8535125823782995 |
| 103 | fedavg | 5 | alpha | 0.7805158192754085 |
| 103 | fedavg | 5 | beta | 0.8207258100499681 |
| 103 | fedavg | 5 | gamma | 0.8454023796832703 |
| 103 | fedavg | 6 | alpha | 0.7749346047207157 |
| 103 | fedavg | 6 | beta | 0.8141503148262303 |
| 103 | fedavg | 6 | gamma | 0.8378455140606444 |
| 103 | fedavg | 7 | alpha | 0.7696007055205267 |
| 103 | fedavg | 7 | beta | 0.8087580443526314 |
| 103 | fedavg | 7 | gamma | 0.8348199474756575 |
| 103 | fedavg | 8 | alpha | 0.7624399899930487 |
| 103 | fedavg | 8 | beta | 0.803272960222534 |
| 103 | fedavg | 8 | gamma | 0.8277441287700461 |
| 103 | fedavg | 9 | alpha | 0.7572399067484643 |
| 103 | fedavg | 9 | beta | 0.7993187034064602 |
| 103 | fedavg | 9 | gamma | 0.8253206299688478 |
| 103 | fedavg | 10 | alpha | 0.757057447984119 |
| 103 | fedavg | 10 | beta | 0.7933182762630914 |
| 103 | fedavg | 10 | gamma | 0.8201429481517821 |
| 103 | fedprox | 1 | alpha | 1.0474234145481671 |
| 103 | fedprox | 1 | beta | 1.0193604111237893 |
| 103 | fedprox | 1 | gamma | 1.0698357955090432 |
| 103 | fedprox | 2 | alpha | 0.8309955296570738 |
| 103 | fedprox | 2 | beta | 0.8679180662670547 |
| 103 | fedprox | 2 | gamma | 0.8947859135758358 |
| 103 | fedprox | 3 | alpha | 0.8052382027567672 |
| 103 | fedprox | 3 | beta | 0.8442335177213242 |
| 103 | fedprox | 3 | gamma | 0.8687615504072643 |
| 103 | fedprox | 4 | alpha | 0.7906683211031571 |
| 103 | fedprox | 4 | beta | 0.8321876666277064 |
| 103 | fedprox | 4 | gamma | 0.8562273240792194 |
| 103 | fedprox | 5 | alpha | 0.7821463326777308 |
| 103 | fedprox | 5 | beta | 0.8230970803174609 |
| 103 | fedprox | 5 | gamma | 0.8477555940546587 |
| 103 | fedprox | 6 | alpha | 0.7773626853318946 |
| 103 | fedprox | 6 | beta | 0.8162403271163773 |
| 103 | fedprox | 6 | gamma | 0.840339668580662 |
| 103 | fedprox | 7 | alpha | 0.7716469093974158 |
| 103 | fedprox | 7 | beta | 0.8114842124318482 |
| 103 | fedprox | 7 | gamma | 0.8366635502376751 |
| 103 | fedprox | 8 | alpha | 0.7648357599208151 |
| 103 | fedprox | 8 | beta | 0.8065833852893104 |
| 103 | fedprox | 8 | gamma | 0.8302699049106695 |
| 103 | fedprox | 9 | alpha | 0.7598259941738632 |
| 103 | fedprox | 9 | beta | 0.8022949351602449 |
| 103 | fedprox | 9 | gamma | 0.8271236932896793 |
| 103 | fedprox | 10 | alpha | 0.7595586544146142 |
| 103 | fedprox | 10 | beta | 0.7963228429294561 |
| 103 | fedprox | 10 | gamma | 0.8224498699967312 |
| 104 | fedavg | 1 | alpha | 1.057389535367662 |
| 104 | fedavg | 1 | beta | 1.0253419953723502 |
| 104 | fedavg | 1 | gamma | 1.0810229383037018 |
| 104 | fedavg | 2 | alpha | 0.8391494457679639 |
| 104 | fedavg | 2 | beta | 0.8666051337014758 |
| 104 | fedavg | 2 | gamma | 0.8959163744439576 |
| 104 | fedavg | 3 | alpha | 0.8076434614590723 |
| 104 | fedavg | 3 | beta | 0.8426640449473891 |
| 104 | fedavg | 3 | gamma | 0.8663640140005073 |
| 104 | fedavg | 4 | alpha | 0.7934618246643198 |
| 104 | fedavg | 4 | beta | 0.8322249262185138 |
| 104 | fedavg | 4 | gamma | 0.8542505534134577 |
| 104 | fedavg | 5 | alpha | 0.7839931660607001 |
| 104 | fedavg | 5 | beta | 0.8215223112167575 |
| 104 | fedavg | 5 | gamma | 0.8466377068263915 |
| 104 | fedavg | 6 | alpha | 0.7730223718087855 |
| 104 | fedavg | 6 | beta | 0.8135177913782518 |
| 104 | fedavg | 6 | gamma | 0.8374762857679807 |
| 104 | fedavg | 7 | alpha | 0.7694883192919556 |
| 104 | fedavg | 7 | beta | 0.8091571078824064 |
| 104 | fedavg | 7 | gamma | 0.8355467578607976 |
| 104 | fedavg | 8 | alpha | 0.7654233925012917 |
| 104 | fedavg | 8 | beta | 0.8031426465364652 |
| 104 | fedavg | 8 | gamma | 0.8282183930083604 |
| 104 | fedavg | 9 | alpha | 0.7591064754330156 |
| 104 | fedavg | 9 | beta | 0.7954962455865667 |
| 104 | fedavg | 9 | gamma | 0.8225913325196544 |
| 104 | fedavg | 10 | alpha | 0.7566661311761593 |
| 104 | fedavg | 10 | beta | 0.7921873250170351 |
| 104 | fedavg | 10 | gamma | 0.8209228531760205 |
| 104 | fedprox | 1 | alpha | 1.06917132624617 |
| 104 | fedprox | 1 | beta | 1.0391518625000595 |
| 104 | fedprox | 1 | gamma | 1.092607591633618 |
| 104 | fedprox | 2 | alpha | 0.8421289856635702 |
| 104 | fedprox | 2 | beta | 0.8703599175017269 |
| 104 | fedprox | 2 | gamma | 0.8982166826474014 |
| 104 | fedprox | 3 | alpha | 0.8105314364118025 |
| 104 | fedprox | 3 | beta | 0.8454823873087892 |
| 104 | fedprox | 3 | gamma | 0.8685987753573605 |
| 104 | fedprox | 4 | alpha | 0.7963452331317384 |
| 104 | fedprox | 4 | beta | 0.8346201480011504 |
| 104 | fedprox | 4 | gamma | 0.8559104239555789 |
| 104 | fedprox | 5 | alpha | 0.7860303033082539 |
| 104 | fedprox | 5 | beta | 0.8241076934202015 |
| 104 | fedprox | 5 | gamma | 0.8485091065676819 |
| 104 | fedprox | 6 | alpha | 0.7749105019443717 |
| 104 | fedprox | 6 | beta | 0.8160777944054737 |
| 104 | fedprox | 6 | gamma | 0.8394492799828902 |
| 104 | fedprox | 7 | alpha | 0.7711478109495007 |
| 104 | fedprox | 7 | beta | 0.8118156118953062 |
| 104 | fedprox | 7 | gamma | 0.836755116752711 |
| 104 | fedprox | 8 | alpha | 0.7665898888564306 |
| 104 | fedprox | 8 | beta | 0.8060218463609676 |
| 104 | fedprox | 8 | gamma | 0.8297946776037635 |
| 104 | fedprox | 9 | alpha | 0.7612435869774383 |
| 104 | fedprox | 9 | beta | 0.7984936332717396 |
| 104 | fedprox | 9 | gamma | 0.8239707012967258 |
| 104 | fedprox | 10 | alpha | 0.7579485850060441 |
| 104 | fedprox | 10 | beta | 0.7945583595595271 |
| 104 | fedprox | 10 | gamma | 0.8220277093253777 |
| 105 | fedavg | 1 | alpha | 1.0003097660445144 |
| 105 | fedavg | 1 | beta | 0.9826928686175028 |
| 105 | fedavg | 1 | gamma | 1.0334222417975418 |
| 105 | fedavg | 2 | alpha | 0.8241552572205633 |
| 105 | fedavg | 2 | beta | 0.8576848431977752 |
| 105 | fedavg | 2 | gamma | 0.8833936411631186 |
| 105 | fedavg | 3 | alpha | 0.8028850775625601 |
| 105 | fedavg | 3 | beta | 0.8377237162943881 |
| 105 | fedavg | 3 | gamma | 0.8612104073205691 |
| 105 | fedavg | 4 | alpha | 0.7877517949131575 |
| 105 | fedavg | 4 | beta | 0.8280452234562563 |
| 105 | fedavg | 4 | gamma | 0.8496376379640111 |
| 105 | fedavg | 5 | alpha | 0.7807358865203244 |
| 105 | fedavg | 5 | beta | 0.8188023480949853 |
| 105 | fedavg | 5 | gamma | 0.8421781932707657 |
| 105 | fedavg | 6 | alpha | 0.7762448291361053 |
| 105 | fedavg | 6 | beta | 0.8118780182212866 |
| 105 | fedavg | 6 | gamma | 0.8371128340821145 |
| 105 | fedavg | 7 | alpha | 0.7666966247989951 |
| 105 | fedavg | 7 | beta | 0.8062621489643432 |
| 105 | fedavg | 7 | gamma | 0.8319342410681553 |
| 105 | fedavg | 8 | alpha | 0.7645378104804854 |
| 105 | fedavg | 8 | beta | 0.8013041263937277 |
| 105 | fedavg | 8 | gamma | 0.8252796385745761 |
| 105 | fedavg | 9 | alpha | 0.7587095897246184 |
| 105 | fedavg | 9 | beta | 0.7962572289345241 |
| 105 | fedavg | 9 | gamma | 0.8220221438626859 |
| 105 | fedavg | 10 | alpha | 0.7558816341462348 |
| 105 | fedavg | 10 | beta | 0.7918800337574924 |
| 105 | fedavg | 10 | gamma | 0.8187227351693703 |
| 105 | fedprox | 1 | alpha | 1.011574543877747 |
| 105 | fedprox | 1 | beta | 0.9958071695026816 |
| 105 | fedprox | 1 | gamma | 1.0439690372043653 |
| 105 | fedprox | 2 | alpha | 0.8265290293998155 |
| 105 | fedprox | 2 | beta | 0.8611758177580963 |
| 105 | fedprox | 2 | gamma | 0.8865304175373642 |
| 105 | fedprox | 3 | alpha | 0.8050136301356127 |
| 105 | fedprox | 3 | beta | 0.8406781286985929 |
| 105 | fedprox | 3 | gamma | 0.8635903859105023 |
| 105 | fedprox | 4 | alpha | 0.789950853337234 |
| 105 | fedprox | 4 | beta | 0.8305975520729807 |
| 105 | fedprox | 4 | gamma | 0.8519248601810379 |
| 105 | fedprox | 5 | alpha | 0.7823240608276468 |
| 105 | fedprox | 5 | beta | 0.8213689566894663 |
| 105 | fedprox | 5 | gamma | 0.844178350721879 |
| 105 | fedprox | 6 | alpha | 0.7780562304534469 |
| 105 | fedprox | 6 | beta | 0.8150570535774175 |
| 105 | fedprox | 6 | gamma | 0.8395611743948994 |
| 105 | fedprox | 7 | alpha | 0.7679785290599428 |
| 105 | fedprox | 7 | beta | 0.8084050251365141 |
| 105 | fedprox | 7 | gamma | 0.8326847447597457 |
| 105 | fedprox | 8 | alpha | 0.765438726205551 |
| 105 | fedprox | 8 | beta | 0.8038905108204698 |
| 105 | fedprox | 8 | gamma | 0.8265750707928872 |
| 105 | fedprox | 9 | alpha | 0.7600369057752256 |
| 105 | fedprox | 9 | beta | 0.7980172440224016 |
| 105 | fedprox | 9 | gamma | 0.8239690784894562 |
| 105 | fedprox | 10 | alpha | 0.7563508124071385 |
| 105 | fedprox | 10 | beta | 0.7939082913508331 |
| 105 | fedprox | 10 | gamma | 0.8198294266684872 |
| 106 | fedavg | 1 | alpha | 1.0073852073488583 |
| 106 | fedavg | 1 | beta | 0.9885261886436983 |
| 106 | fedavg | 1 | gamma | 1.0352784796805234 |
| 106 | fedavg | 2 | alpha | 0.8250906436550369 |
| 106 | fedavg | 2 | beta | 0.8597076451926927 |
| 106 | fedavg | 2 | gamma | 0.8886292204006846 |
| 106 | fedavg | 3 | alpha | 0.7989915421106518 |
| 106 | fedavg | 3 | beta | 0.8395069379523509 |
| 106 | fedavg | 3 | gamma | 0.8634395125348749 |
| 106 | fedavg | 4 | alpha | 0.7866883004832699 |
| 106 | fedavg | 4 | beta | 0.825496778813418 |
| 106 | fedavg | 4 | gamma | 0.8533693396760678 |
| 106 | fedavg | 5 | alpha | 0.7804014296677594 |
| 106 | fedavg | 5 | beta | 0.8166824136827878 |
| 106 | fedavg | 5 | gamma | 0.8442759385968536 |
| 106 | fedavg | 6 | alpha | 0.7733230353040782 |
| 106 | fedavg | 6 | beta | 0.810699831878568 |
| 106 | fedavg | 6 | gamma | 0.8392598560154259 |
| 106 | fedavg | 7 | alpha | 0.7650371554282884 |
| 106 | fedavg | 7 | beta | 0.8048636314808598 |
| 106 | fedavg | 7 | gamma | 0.8315091433830101 |
| 106 | fedavg | 8 | alpha | 0.7590174524145572 |
| 106 | fedavg | 8 | beta | 0.7992753807691969 |
| 106 | fedavg | 8 | gamma | 0.828203019958138 |
| 106 | fedavg | 9 | alpha | 0.7595819323782359 |
| 106 | fedavg | 9 | beta | 0.7934897973756436 |
| 106 | fedavg | 9 | gamma | 0.8230894087597724 |
| 106 | fedavg | 10 | alpha | 0.7545983012377058 |
| 106 | fedavg | 10 | beta | 0.7885211940143053 |
| 106 | fedavg | 10 | gamma | 0.8227034833738649 |
| 106 | fedprox | 1 | alpha | 1.0171637162050287 |
| 106 | fedprox | 1 | beta | 1.0015562116467878 |
| 106 | fedprox | 1 | gamma | 1.0457812744413704 |
| 106 | fedprox | 2 | alpha | 0.8288776366231908 |
| 106 | fedprox | 2 | beta | 0.8635528574212734 |
| 106 | fedprox | 2 | gamma | 0.8917164941672598 |
| 106 | fedprox | 3 | alpha | 0.8023004114081984 |
| 106 | fedprox | 3 | beta | 0.843036886879712 |
| 106 | fedprox | 3 | gamma | 0.8661298970313691 |
| 106 | fedprox | 4 | alpha | 0.789299913274941 |
| 106 | fedprox | 4 | beta | 0.8290424766457876 |
| 106 | fedprox | 4 | gamma | 0.8556566289677419 |
| 106 | fedprox | 5 | alpha | 0.7823110878374365 |
| 106 | fedprox | 5 | beta | 0.8197822182307457 |
| 106 | fedprox | 5 | gamma | 0.8468950698579842 |
| 106 | fedprox | 6 | alpha | 0.7760056287735894 |
| 106 | fedprox | 6 | beta | 0.8137040344460188 |
| 106 | fedprox | 6 | gamma | 0.8415636371246722 |
| 106 | fedprox | 7 | alpha | 0.7667187542448838 |
| 106 | fedprox | 7 | beta | 0.8082724032429344 |
| 106 | fedprox | 7 | gamma | 0.8341308067359833 |
| 106 | fedprox | 8 | alpha | 0.7611969516084001 |
| 106 | fedprox | 8 | beta | 0.8033083589704452 |
| 106 | fedprox | 8 | gamma | 0.8308604582412128 |
| 106 | fedprox | 9 | alpha | 0.7613096577476278 |
| 106 | fedprox | 9 | beta | 0.7963295446629957 |
| 106 | fedprox | 9 | gamma | 0.8247965203991438 |
| 106 | fedprox | 10 | alpha | 0.756559074297797 |
| 106 | fedprox | 10 | beta | 0.7917256308609253 |
| 106 | fedprox | 10 | gamma | 0.8253074572706404 |
| 107 | fedavg | 1 | alpha | 1.024719287008746 |
| 107 | fedavg | 1 | beta | 1.0039718305973282 |
| 107 | fedavg | 1 | gamma | 1.0561094654808787 |
| 107 | fedavg | 2 | alpha | 0.827519323933942 |
| 107 | fedavg | 2 | beta | 0.8623744625752993 |
| 107 | fedavg | 2 | gamma | 0.8881759484353992 |
| 107 | fedavg | 3 | alpha | 0.8031255518961411 |
| 107 | fedavg | 3 | beta | 0.8433692069934782 |
| 107 | fedavg | 3 | gamma | 0.864468121698344 |
| 107 | fedavg | 4 | alpha | 0.7890407089838791 |
| 107 | fedavg | 4 | beta | 0.8291187501217497 |
| 107 | fedavg | 4 | gamma | 0.8527241441011668 |
| 107 | fedavg | 5 | alpha | 0.778273728507849 |
| 107 | fedavg | 5 | beta | 0.8197956457601504 |
| 107 | fedavg | 5 | gamma | 0.8432596296830959 |
| 107 | fedavg | 6 | alpha | 0.7732980122969889 |
| 107 | fedavg | 6 | beta | 0.8146787773554589 |
| 107 | fedavg | 6 | gamma | 0.8391836944146555 |
| 107 | fedavg | 7 | alpha | 0.7682311386702075 |
| 107 | fedavg | 7 | beta | 0.8080349536048345 |
| 107 | fedavg | 7 | gamma | 0.8314206131670646 |
| 107 | fedavg | 8 | alpha | 0.7620424598834864 |
| 107 | fedavg | 8 | beta | 0.8007111172414846 |
| 107 | fedavg | 8 | gamma | 0.8260569703920776 |
| 107 | fedavg | 9 | alpha | 0.7589303877621536 |
| 107 | fedavg | 9 | beta | 0.7963562616620797 |
| 107 | fedavg | 9 | gamma | 0.8229402095491766 |
| 107 | fedavg | 10 | alpha | 0.7558042624312531 |
| 107 | fedavg | 10 | beta | 0.7934546471011074 |
| 107 | fedavg | 10 | gamma | 0.8211427800206448 |
| 107 | fedprox | 1 | alpha | 1.0358135686113494 |
| 107 | fedprox | 1 | beta | 1.01771699710683 |
| 107 | fedprox | 1 | gamma | 1.066999812163928 |
| 107 | fedprox | 2 | alpha | 0.8302731778916169 |
| 107 | fedprox | 2 | beta | 0.8664390458823044 |
| 107 | fedprox | 2 | gamma | 0.8914726021439464 |
| 107 | fedprox | 3 | alpha | 0.805532080642022 |
| 107 | fedprox | 3 | beta | 0.8464127479761477 |
| 107 | fedprox | 3 | gamma | 0.8668561454332733 |
| 107 | fedprox | 4 | alpha | 0.7912474093571396 |
| 107 | fedprox | 4 | beta | 0.8320680326106682 |
| 107 | fedprox | 4 | gamma | 0.8550979932013796 |
| 107 | fedprox | 5 | alpha | 0.7806967514312664 |
| 107 | fedprox | 5 | beta | 0.8225080886741711 |
| 107 | fedprox | 5 | gamma | 0.8458561527243783 |
| 107 | fedprox | 6 | alpha | 0.774790293927541 |
| 107 | fedprox | 6 | beta | 0.8172309583880755 |
| 107 | fedprox | 6 | gamma | 0.8407449484325636 |
| 107 | fedprox | 7 | alpha | 0.7696846590554418 |
| 107 | fedprox | 7 | beta | 0.8099189356810019 |
| 107 | fedprox | 7 | gamma | 0.8341031611288433 |
| 107 | fedprox | 8 | alpha | 0.7634100451755929 |
| 107 | fedprox | 8 | beta | 0.8029967202293811 |
| 107 | fedprox | 8 | gamma | 0.8286847612268345 |
| 107 | fedprox | 9 | alpha | 0.7600269917134918 |
| 107 | fedprox | 9 | beta | 0.7992297071131318 |
| 107 | fedprox | 9 | gamma | 0.8251564567256887 |
| 107 | fedprox | 10 | alpha | 0.7575180854199852 |
| 107 | fedprox | 10 | beta | 0.7959153068690148 |
| 107 | fedprox | 10 | gamma | 0.8237678470056043 |
| 108 | fedavg | 1 | alpha | 1.0520082147147525 |
| 108 | fedavg | 1 | beta | 1.01670454199318 |
| 108 | fedavg | 1 | gamma | 1.0707034977925716 |
| 108 | fedavg | 2 | alpha | 0.8332721873908163 |
| 108 | fedavg | 2 | beta | 0.8648518984931952 |
| 108 | fedavg | 2 | gamma | 0.8919755019978098 |
| 108 | fedavg | 3 | alpha | 0.8038103425904846 |
| 108 | fedavg | 3 | beta | 0.844921145402803 |
| 108 | fedavg | 3 | gamma | 0.8684378077970948 |
| 108 | fedavg | 4 | alpha | 0.7904936559556557 |
| 108 | fedavg | 4 | beta | 0.8312227715282149 |
| 108 | fedavg | 4 | gamma | 0.8565260323680711 |
| 108 | fedavg | 5 | alpha | 0.7836932235992139 |
| 108 | fedavg | 5 | beta | 0.8230949314369521 |
| 108 | fedavg | 5 | gamma | 0.8481839578042223 |
| 108 | fedavg | 6 | alpha | 0.7723602366841529 |
| 108 | fedavg | 6 | beta | 0.8154376583470931 |
| 108 | fedavg | 6 | gamma | 0.8411849122834344 |
| 108 | fedavg | 7 | alpha | 0.768459097333111 |
| 108 | fedavg | 7 | beta | 0.8090639709042643 |
| 108 | fedavg | 7 | gamma | 0.8351353629691486 |
| 108 | fedavg | 8 | alpha | 0.7621875045713314 |
| 108 | fedavg | 8 | beta | 0.8024907264004345 |
| 108 | fedavg | 8 | gamma | 0.8312764721043917 |
| 108 | fedavg | 9 | alpha | 0.7580429715238992 |
| 108 | fedavg | 9 | beta | 0.7969176540579173 |
| 108 | fedavg | 9 | gamma | 0.82659896621968 |
| 108 | fedavg | 10 | alpha | 0.753689093131265 |
| 108 | fedavg | 10 | beta | 0.7921974894654167 |
| 108 | fedavg | 10 | gamma | 0.8205537075434176 |
| 108 | fedprox | 1 | alpha | 1.0632588266793814 |
| 108 | fedprox | 1 | beta | 1.0299092386470512 |
| 108 | fedprox | 1 | gamma | 1.0816709093132502 |
| 108 | fedprox | 2 | alpha | 0.8359355304638989 |
| 108 | fedprox | 2 | beta | 0.8681085827475518 |
| 108 | fedprox | 2 | gamma | 0.8946104987795425 |
| 108 | fedprox | 3 | alpha | 0.8065702463996338 |
| 108 | fedprox | 3 | beta | 0.84770317669117 |
| 108 | fedprox | 3 | gamma | 0.870096120610609 |
| 108 | fedprox | 4 | alpha | 0.7923362297300305 |
| 108 | fedprox | 4 | beta | 0.8340668236702891 |
| 108 | fedprox | 4 | gamma | 0.8586813302395792 |
| 108 | fedprox | 5 | alpha | 0.785472319651747 |
| 108 | fedprox | 5 | beta | 0.8256285596925168 |
| 108 | fedprox | 5 | gamma | 0.8502814434730196 |
| 108 | fedprox | 6 | alpha | 0.7744707897328788 |
| 108 | fedprox | 6 | beta | 0.8171931847112426 |
| 108 | fedprox | 6 | gamma | 0.8425255848574021 |
| 108 | fedprox | 7 | alpha | 0.7705080050668042 |
| 108 | fedprox | 7 | beta | 0.8114100220697283 |
| 108 | fedprox | 7 | gamma | 0.8363531646136653 |
| 108 | fedprox | 8 | alpha | 0.764738443163002 |
| 108 | fedprox | 8 | beta | 0.8048381312919421 |
| 108 | fedprox | 8 | gamma | 0.8330568479994435 |
| 108 | fedprox | 9 | alpha | 0.7601890094396869 |
| 108 | fedprox | 9 | beta | 0.7993891872157164 |
| 108 | fedprox | 9 | gamma | 0.8284601055598101 |
| 108 | fedprox | 10 | alpha | 0.7550355452151338 |
| 108 | fedprox | 10 | beta | 0.7951929511267879 |
| 108 | fedprox | 10 | gamma | 0.8218953108319018 |
| 109 | fedavg | 1 | alpha | 0.990099706685993 |
| 109 | fedavg | 1 | beta | 0.9741899874163681 |
| 109 | fedavg | 1 | gamma | 1.032468835552637 |
| 109 | fedavg | 2 | alpha | 0.82125819501585 |
| 109 | fedavg | 2 | beta | 0.8598862534418735 |
| 109 | fedavg | 2 | gamma | 0.8865935836522929 |
| 109 | fedavg | 3 | alpha | 0.7995581227752655 |
| 109 | fedavg | 3 | beta | 0.8398976950170196 |
| 109 | fedavg | 3 | gamma | 0.8653489174263401 |
| 109 | fedavg | 4 | alpha | 0.7895454885652349 |
| 109 | fedavg | 4 | beta | 0.8279963121928547 |
| 109 | fedavg | 4 | gamma | 0.8521031399683457 |
| 109 | fedavg | 5 | alpha | 0.7816196563309369 |
| 109 | fedavg | 5 | beta | 0.8189661311658647 |
| 109 | fedavg | 5 | gamma | 0.8476222916430597 |
| 109 | fedavg | 6 | alpha | 0.7732624403594832 |
| 109 | fedavg | 6 | beta | 0.811948346125861 |
| 109 | fedavg | 6 | gamma | 0.8383700701930802 |
| 109 | fedavg | 7 | alpha | 0.7666906560002519 |
| 109 | fedavg | 7 | beta | 0.8063656746497107 |
| 109 | fedavg | 7 | gamma | 0.8346314050163084 |
| 109 | fedavg | 8 | alpha | 0.7657001865264266 |
| 109 | fedavg | 8 | beta | 0.8002765416997528 |
| 109 | fedavg | 8 | gamma | 0.8285042785297827 |
| 109 | fedavg | 9 | alpha | 0.7605625445458781 |
| 109 | fedavg | 9 | beta | 0.7957488162814764 |
| 109 | fedavg | 9 | gamma | 0.8278541495380742 |
| 109 | fedavg | 10 | alpha | 0.7539744014076444 |
| 109 | fedavg | 10 | beta | 0.791037801954387 |
| 109 | fedavg | 10 | gamma | 0.8194192704347419 |
| 109 | fedprox | 1 | alpha | 0.9998279379924973 |
| 109 | fedprox | 1 | beta | 0.9861529579170346 |
| 109 | fedprox | 1 | gamma | 1.0415802901102398 |
| 109 | fedprox | 2 | alpha | 0.8242188288293727 |
| 109 | fedprox | 2 | beta | 0.8631637993265138 |
| 109 | fedprox | 2 | gamma | 0.8894369728894613 |
| 109 | fedprox | 3 | alpha | 0.8023170196560043 |
| 109 | fedprox | 3 | beta | 0.8432044937017854 |
| 109 | fedprox | 3 | gamma | 0.8679638296897602 |
| 109 | fedprox | 4 | alpha | 0.7916365310047151 |
| 109 | fedprox | 4 | beta | 0.8305069053264389 |
| 109 | fedprox | 4 | gamma | 0.8544095590880956 |
| 109 | fedprox | 5 | alpha | 0.7842017829431496 |
| 109 | fedprox | 5 | beta | 0.8222112782477669 |
| 109 | fedprox | 5 | gamma | 0.849754253728418 |
| 109 | fedprox | 6 | alpha | 0.7745952657458237 |
| 109 | fedprox | 6 | beta | 0.8150640011691627 |
| 109 | fedprox | 6 | gamma | 0.840797480921098 |
| 109 | fedprox | 7 | alpha | 0.7685386603608684 |
| 109 | fedprox | 7 | beta | 0.8092463772787469 |
| 109 | fedprox | 7 | gamma | 0.8366051556974655 |
| 109 | fedprox | 8 | alpha | 0.7676644223274758 |
| 109 | fedprox | 8 | beta | 0.8028477535503877 |
| 109 | fedprox | 8 | gamma | 0.8306433110144374 |
| 109 | fedprox | 9 | alpha | 0.7623359838287187 |
| 109 | fedprox | 9 | beta | 0.7984087079807229 |
| 109 | fedprox | 9 | gamma | 0.8293256761675395 |
| 109 | fedprox | 10 | alpha | 0.755851069424923 |
| 109 | fedprox | 10 | beta | 0.7939141682774845 |
| 109 | fedprox | 10 | gamma | 0.8216752266271907 |

## Importancia Permutacion

| dimension | group | features | mean_cost_increase | sd_cost_increase | rank | source_file |
| --- | --- | --- | --- | --- | --- | --- |
| temporal_statistic | trend | 105 | 0.24891002774474855 | 0.29011969639309126 | 1 | results/09_interpretabilidad/permutation_importance.csv |
| temporal_statistic | last | 105 | 0.2263839344695473 | 0.0177634646818773 | 2 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 167_6 | 5 | 0.11989694807768576 | 0.0011890606420932315 | 3 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 158_8 | 5 | 0.07887435592548601 | 0.012039952579535 | 4 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 158_3 | 5 | 0.06744616197648352 | 0.043644057124158205 | 5 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 397_12 | 5 | 0.0562161448011634 | 0.03323486141195423 | 6 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 171_0 | 5 | 0.042806183115339756 | 0.001237613554973642 | 7 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 397_0 | 5 | 0.03923900118906154 | 0.13998141743595469 | 8 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 397_2 | 5 | 0.038842647641696836 | 0.006867904657615553 | 9 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 459_9 | 5 | 0.038115999471528994 | 0.013884165383130722 | 10 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 167_9 | 5 | 0.03771964592416488 | 0.0037723058621397135 | 11 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 158_9 | 5 | 0.037191174527679394 | 0.043482681819526636 | 12 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 397_33 | 5 | 0.03474699431893313 | 0.005775529923211372 | 13 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | 158_0 | 5 | 0.03382216937508294 | 0.0032036875817098897 | 14 | results/09_interpretabilidad/permutation_importance.csv |
| source_variable | window | 2 | 0.03263310873299 | 0.0038648705182481617 | 15 | results/09_interpretabilidad/permutation_importance.csv |

## Procedencia

```json
{
  "commit": "eaf5393a1a8b0ce1efb00194584cbadd2ae6e02f",
  "hardware": {
    "platform": "Windows-11-10.0.26200-SP0",
    "processor": "AMD64 Family 23 Model 104 Stepping 1, AuthenticAMD",
    "cpu_count": 16
  },
  "versions": {
    "python": "3.12.6 (tags/v3.12.6:a4a2d2b, Sep  6 2024, 20:11:23) [MSC v.1940 64 bit (AMD64)]",
    "numpy": "1.26.4"
  },
  "timing_seconds": 194.44612140000027,
  "configuration": {
    "name": "b_unweighted_cost",
    "weighted_loss": false,
    "decision": "cost",
    "prior_correction": false
  },
  "hashes": {
    "cache_train": "19bddfac95cf18c97f6d8e6f1761052eacb969a34789b5a0f8974ac0542393d1",
    "cache_validation": "d1b29c458be0f3ab1b49f887b5067609fd07922fc0720b8cb1e946b214244a89",
    "cache_metadata": "510bf23d18b0463c8fc9f0494e86fbea516707fdaff8ce3e0e96b3146973aa60",
    "seed_100_metrics": "464bb693e00b7e281934ec98e4d60953f3b9455466337e74a7eed181efbb4602",
    "diagnostics": "9603b28961da5a9dbed8a6242c9162074c78c35c76a262967bf91b752885467c",
    "interpretability": "6fc6769a4bd8e65c63431fa844ccf0dc47d5301d5b42bbb4a3ff3633cc4b6ed7"
  }
}
```

## Figuras PNG a 300 dpi

- distribucion_clases.png
- costo_por_regimen.png
- perdidas_federadas.png
- matrices_confusion.png
- importancia_permutacion.png
- seleccion_variante.png
